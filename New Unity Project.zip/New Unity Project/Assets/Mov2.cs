﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Mov2 : MonoBehaviour {

	public float speed;
	private Rigidbody rigid;
	// Use this for initialization
	void Start () {
		rigid = GetComponent<Rigidbody> ();
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		if (Input.GetKey (KeyCode.W))
		{
			Vector3 move=new Vector3(0f, 0f, 1f);
			transform.Translate(move * Time.deltaTime * speed);
			rigid.AddForce (move * speed);
		}      
		if (Input.GetKey (KeyCode.A))
		{
			Vector3 move=new Vector3(-1f, 0f, 0f);
			transform.Translate(move * Time.deltaTime * speed);
			rigid.AddForce (move * speed);
		}      
		if (Input.GetKey (KeyCode.S))
		{
			Vector3 move=new Vector3(0f, 0f, -1f);
			transform.Translate(move * Time.deltaTime * speed);
			rigid.AddForce (move * speed);
		}
		
		if (Input.GetKey (KeyCode.D))
		{     
			Vector3 move=new Vector3(1f, 0f, 0f);
			transform.Translate(move* Time.deltaTime * speed); 
			//rigid.AddForce (move * speed);
		}
		

	}
}
